       <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('header', null, []); ?> 
               <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                   <?php echo e(__('Dashboard')); ?>

               </h2>
               <!-- Breadcrumb -->
               <div
                   class="sticky top-0 inset-x-0 z-20 bg-white border-y px-4 sm:px-6 lg:px-8  dark:bg-neutral-800 dark:border-neutral-700">
                   <div class="flex items-center py-2">
                       <!-- Navigation Toggle -->
                       <button type="button"
                           class="size-8 flex justify-center items-center gap-x-2 border border-gray-200 text-gray-800 hover:text-gray-500 rounded-lg focus:outline-none focus:text-gray-500 disabled:opacity-50 disabled:pointer-events-none dark:border-neutral-700 dark:text-neutral-200 dark:hover:text-neutral-500 dark:focus:text-neutral-500"
                           aria-haspopup="dialog" aria-expanded="false" aria-controls="hs-application-sidebar"
                           aria-label="Toggle navigation" data-hs-overlay="#hs-application-sidebar">
                           <span class="sr-only">Toggle Navigation</span>
                           <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                               viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                               stroke-linecap="round" stroke-linejoin="round">
                               <rect width="18" height="18" x="3" y="3" rx="2" />
                               <path d="M15 3v18" />
                               <path d="m8 9 3 3-3 3" />
                           </svg>
                       </button>
                       <!-- End Navigation Toggle -->

                       <!-- Breadcrumb -->
                       <ol class="ms-3 flex items-center whitespace-nowrap">
                           <li class="flex items-center text-sm text-gray-800 dark:text-neutral-400">
                               Application Layout
                               <svg class="shrink-0 mx-3 overflow-visible size-2.5 text-gray-400 dark:text-neutral-500"
                                   width="16" height="16" viewBox="0 0 16 16" fill="none"
                                   xmlns="http://www.w3.org/2000/svg">
                                   <path d="M5 1L10.6869 7.16086C10.8637 7.35239 10.8637 7.64761 10.6869 7.83914L5 14"
                                       stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                               </svg>
                           </li>
                           <li class="text-sm font-semibold text-gray-800 truncate dark:text-neutral-400"
                               aria-current="page">
                               Dashboard
                           </li>
                       </ol>
                       <!-- End Breadcrumb -->
                   </div>
               </div>
               <!-- End Breadcrumb -->
            <?php $__env->endSlot(); ?>

           <div class="py-12">
               <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                   <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                       <div class="p-6 text-gray-900 dark:text-gray-100">
                           <?php echo e(__("You're logged in!")); ?>

                       </div>
                   </div>
               </div>
           </div>
        <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\scic\resources\views/dashboard2.blade.php ENDPATH**/ ?>